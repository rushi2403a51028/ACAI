// backend/models/Issued.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const IssuedSchema = new Schema({
  roll: { type: String, required: true }, // student's username / roll
  book: { type: Schema.Types.ObjectId, ref: 'Book', required: true },
  issueDate: { type: Date, default: Date.now },
  dueDate: { type: Date },
}, { timestamps: true });

module.exports = mongoose.model('Issued', IssuedSchema);
