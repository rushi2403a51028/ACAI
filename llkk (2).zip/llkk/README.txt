Library Full Pack - Backend + Frontend

Structure:
- backend/        -> Node.js + Express + Mongoose backend
  - models/Book.js
  - models/Issued.js
  - models/User.js
  - config/db.js
  - server.js
  - package.json
  - .env.example
- frontend/
  - pro1.html    -> your original frontend (copied from your uploaded file)

How to run (VS Code):
1. Install Node.js (>=16) and MongoDB (or use Atlas).
2. Open the folder in VS Code (File -> Open Folder -> library_full_pack)
3. In backend folder open terminal:
   - cp .env.example .env
   - edit .env and set MONGO_URI and JWT_SECRET
   - npm install
   - npm start
4. Backend runs on PORT (default 3000).
5. Open frontend/pro1.html in browser. The frontend is prewired to talk to the API at http://localhost:3000 (you may need to update endpoints).

Notes:
- There is a simple auth system: register/login at /api/auth
- Create a staff user by POST /api/auth/register with {username, password, role: "staff"}