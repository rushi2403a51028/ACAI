def factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)

def main():
    try:
        num = int(input("Enter a number: "))
        result = factorial(num)
        print(f"Factorial of {num} is {result}")
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()