# Read three values from the user
a = float(input("Enter first value: "))
b = float(input("Enter second value: "))
c = float(input("Enter third value: "))

# Find the maximum value
maximum = max(a, b, c)

print("The maximum value is:", maximum)